package com.ssau.backend.service;


import com.ssau.backend.dto.ProjectPojo;
import com.ssau.backend.dto.TaskPojo;
import com.ssau.backend.entity.Project;
import com.ssau.backend.entity.Task;
import com.ssau.backend.repository.ProjectRepository;

import com.ssau.backend.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class ProjectService {
    private final ProjectRepository projectRepository;

    public List<ProjectPojo> findAll(String search) {
        List<ProjectPojo> result = new ArrayList<>();
        for (Project project : Objects.equals(search, "") ? projectRepository.findAll() : projectRepository.selectByName(search))
            result.add(ProjectPojo.fromEntity(project));
        return result;
    }

    public ProjectPojo findById(long id_project) {
        return projectRepository.findById(id_project).map(ProjectPojo::fromEntity).orElse(null);
    }

    public ProjectPojo createProject(ProjectPojo pojo) {
        Project project = ProjectPojo.toEntity(pojo);
        return ProjectPojo.fromEntity(projectRepository.save(project));
    }

    public ProjectPojo updateProject(long id_project, ProjectPojo pojo) {
        ProjectPojo byId = findById(id_project);

        if (byId != null) {
            Project project = ProjectPojo.toEntity(byId);
            project.setName_project(pojo.getName_project());
            project.setDescription_of_the_project(pojo.getDescription_of_the_project());
            project.setStart_date_project(pojo.getStart_date_project());
            project.setCompletion_date_project(pojo.getCompletion_date_project());
            return ProjectPojo.fromEntity(projectRepository.save(project));
        } else {
            return null;
        }
    }

    public boolean deleteProject(long id_project) {
        if (projectRepository.existsById(id_project)) {
            projectRepository.deleteById(id_project);
            return true;
        } else return false;
    }

    public HashMap<Long, Integer> findHashMap() {
        HashMap<Long, Integer> hashMap = new HashMap<>();
        for (Project project : projectRepository.findAll()) {
            int count = 0;
            for (Task task : project.getTasks()) {
                if (!task.isCompletion_flag_task())
                    count++;
            }
            hashMap.put(project.getId_project(), count);
        }
        return hashMap;
    }
}
