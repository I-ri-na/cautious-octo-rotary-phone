package com.ssau.backend.controller;

import com.ssau.backend.dto.LearningPlanPojo;

import com.ssau.backend.service.LearningPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/groupid/{id_groupid}/learningplan")
public class LearningPlanController {
    @Autowired
    private LearningPlanService learningPlanService;

    @GetMapping()
    public ResponseEntity<List<LearningPlanPojo>> findAllLearningPlansByIdGroup(@PathVariable long id_groupid) {
        List<LearningPlanPojo> listTask = learningPlanService.findAllLearningPlans(id_groupid);
        if(listTask==null||listTask.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listTask, HttpStatus.OK);
    }

    @GetMapping("/{id_learningplan}")
    public ResponseEntity<LearningPlanPojo> findById(@PathVariable long id_groupid, @PathVariable long id_learningplan) {
        LearningPlanPojo taskPojo = learningPlanService.findById(id_groupid, id_learningplan);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<LearningPlanPojo> createTask(@PathVariable long id_groupid, @RequestBody LearningPlanPojo pojo) {
        return new ResponseEntity<>(learningPlanService.create(id_groupid, pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_learningplan}")
    public ResponseEntity<LearningPlanPojo> updateTask(@PathVariable long id_groupid, @PathVariable long id_learningplan, @RequestBody LearningPlanPojo pojo) {
        LearningPlanPojo taskPojo = learningPlanService.update(id_groupid, id_learningplan, pojo);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @DeleteMapping("/{id_learningplan}")
    public ResponseEntity<Boolean> deleteTask(@PathVariable long id_groupid, @PathVariable long id_learningplan) {
        return new ResponseEntity<>(learningPlanService.delete(id_groupid, id_learningplan), HttpStatus.NO_CONTENT);
    }
}

//{
//        "code_discipline": "101",
//        "number_semester": "2",
//        "count_hours": "36"
//}