package com.ssau.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackApplication.class, args);
	}

}
//{
//		"name_project": "name20",
//		"description_of_the_project": "descdesc77",
//		"start_date_project": "2023-01-19",
//		"completion_date_project": "2024-01-19"
//}


//{
//	"name_task": "task2",
//	"description_of_the_task": "desc1",
//	"completion_flag_task": true,
//	"planned_completion_date_task": "2020-02-02"
//}