package com.ssau.backend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "entranceexam", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = {"name_exam","id_student"})})
public class EntranceExam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_entranceexam;

    private String name_exam;

    private int result_exam;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_student", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    private Student student;

}
