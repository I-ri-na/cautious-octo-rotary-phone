package com.ssau.backend.service;

import com.ssau.backend.dto.GroupidPojo;
import com.ssau.backend.dto.LearningPlanPojo;
import com.ssau.backend.dto.ProjectPojo;
import com.ssau.backend.dto.StudentPojo;
import com.ssau.backend.entity.LearningPlan;
import com.ssau.backend.entity.Student;
import com.ssau.backend.repository.GroupidRepository;
import com.ssau.backend.repository.LearningPlanRepository;
import com.ssau.backend.repository.ProjectRepository;
import com.ssau.backend.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class LearningPlanService {

    private final LearningPlanRepository learningPlanRepository;
    private final GroupidRepository groupidRepository;

    public List<LearningPlanPojo> findAllLearningPlans(long id_project) {
        if(id_project!=0) {
            GroupidPojo project = GroupidPojo.fromEntity(groupidRepository.findById(id_project).orElseThrow());
            return project.getLearningplans();
        }
        else {
            List<LearningPlanPojo> result = new ArrayList<>();
            for (LearningPlan learningPlan : learningPlanRepository.findAll())
                result.add(LearningPlanPojo.fromEntity(learningPlan));
            return result;
        }
    }

    public LearningPlanPojo findById(long id_project, long id_task) {
        LearningPlan task = learningPlanRepository.findById(id_task).orElseThrow();
        if(task.getGroupid().getId_groupid()==id_project)
            return LearningPlanPojo.fromEntity(task);
        else
            return null;
    }

    public LearningPlanPojo create(long id_project, LearningPlanPojo pojo) {
        LearningPlan task = LearningPlanPojo.toEntity(pojo);
        task.setGroupid(groupidRepository.findById(id_project).orElseThrow());
        return LearningPlanPojo.fromEntity(learningPlanRepository.save(task));
    }

    public LearningPlanPojo update(long id_project, long id_task, LearningPlanPojo pojo) {
        LearningPlanPojo taskPojo = findById(id_project, id_task);
        if(taskPojo!=null) {
            LearningPlan learningplan = LearningPlanPojo.toEntity(taskPojo);
            learningplan.setCode_discipline(pojo.getCode_discipline());
            learningplan.setNumber_semester(pojo.getNumber_semester());
            learningplan.setCount_hours(pojo.getCount_hours());
            learningplan.setGroupid(groupidRepository.findById(id_project).orElseThrow());
            return LearningPlanPojo.fromEntity(learningPlanRepository.save(learningplan));
        }
        else
            return null;
    }
    public boolean delete(long id_project, long id_task) {
        if (findById(id_project, id_task)!=null)
        {
            learningPlanRepository.deleteById(id_task);
            return true;
        }
        else
            return false;
    }

}
