package com.ssau.backend.service;

import com.ssau.backend.dto.DocumentPojo;
import com.ssau.backend.dto.EntranceExamPojo;
import com.ssau.backend.dto.StudentPojo;
import com.ssau.backend.entity.Document;
import com.ssau.backend.entity.EntranceExam;
import com.ssau.backend.repository.DocumentRepository;

import com.ssau.backend.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final StudentRepository studentRepository;

    public List<DocumentPojo> findAllDocuments(long id_student) {

        if(id_student!=0) {
            StudentPojo project = StudentPojo.fromEntity(studentRepository.findById(id_student).orElseThrow());
            return project.getDocuments();
        }
        else {
            List<DocumentPojo> result = new ArrayList<>();
            for (Document document : documentRepository.findAll())
                result.add(DocumentPojo.fromEntity(document));
            return result;
        }
    }

    public DocumentPojo findById(long id_student, long id_document) {
        Document task = documentRepository.findById(id_document).orElseThrow();
        if (task.getStudent().getId_student() == id_student)
            return DocumentPojo.fromEntity(task);
        else
            return null;
    }

    public DocumentPojo create(long id_student, DocumentPojo pojo) {
        Document task = DocumentPojo.toEntity(pojo);
        task.setStudent(studentRepository.findById(id_student).orElseThrow());
        return DocumentPojo.fromEntity(documentRepository.save(task));
    }

    public DocumentPojo update(long id_student, long id_document, DocumentPojo pojo) {
        DocumentPojo taskPojo = findById(id_student, id_document);
        if (taskPojo != null) {
            Document document = DocumentPojo.toEntity(taskPojo);
            document.setName_document(pojo.getName_document());
            document.setHave_document(pojo.isHave_document());
            document.setStudent(studentRepository.findById(id_student).orElseThrow());
            return DocumentPojo.fromEntity(documentRepository.save(document));
        } else
            return null;
    }

    public boolean delete(long id_student, long id_document) {
        if (findById(id_student, id_document) != null) {
            documentRepository.deleteById(id_document);
            return true;
        } else
            return false;
    }

}
