package com.ssau.backend.dto;

import com.ssau.backend.entity.Document;
import com.ssau.backend.entity.Student;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentPojo {

    private long id_document;
    private String name_document;
    private boolean have_document;
    private Student student;

    public static DocumentPojo fromEntity(Document document){
        DocumentPojo pojo = new DocumentPojo();
        pojo.setId_document(document.getId_document());
        pojo.setName_document(document.getName_document());
        pojo.setHave_document(document.isHave_document());
        pojo.setStudent(document.getStudent());
        return pojo;
    }

    public static Document toEntity(DocumentPojo pojo){
        Document document = new Document();
        document.setId_document(pojo.getId_document());
        document.setName_document(pojo.getName_document());
        document.setHave_document(pojo.isHave_document());
        document.setStudent(pojo.getStudent());
        return document;
    }
}
