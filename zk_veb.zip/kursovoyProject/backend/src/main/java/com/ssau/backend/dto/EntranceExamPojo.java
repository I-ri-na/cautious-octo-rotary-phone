package com.ssau.backend.dto;

import com.ssau.backend.entity.EntranceExam;
import com.ssau.backend.entity.Student;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EntranceExamPojo {

    private long id_entranceexam;
    private String name_exam;
    private int result_exam;
    private Student student;

    public static EntranceExamPojo fromEntity(EntranceExam entranceexam){
        EntranceExamPojo pojo = new EntranceExamPojo();
        pojo.setId_entranceexam(entranceexam.getId_entranceexam());
        pojo.setName_exam(entranceexam.getName_exam());
        pojo.setResult_exam(entranceexam.getResult_exam());
        pojo.setStudent(entranceexam.getStudent());
        return pojo;
    }

    public static EntranceExam toEntity(EntranceExamPojo pojo){
        EntranceExam entranceexam = new EntranceExam();
        entranceexam.setId_entranceexam(pojo.getId_entranceexam());
        entranceexam.setName_exam(pojo.getName_exam());
        entranceexam.setResult_exam(pojo.getResult_exam());
        entranceexam.setStudent(pojo.getStudent());
        return entranceexam;
    }
}
