package com.ssau.backend.controller;

import com.ssau.backend.dto.ProjectPojo;
import com.ssau.backend.dto.TaskPojo;
import com.ssau.backend.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/project/{id_project}/task")
public class TaskController {
    @Autowired
    private TaskService taskService;

    @GetMapping()
    public ResponseEntity<List<TaskPojo>> findAllTasksByIdProject(@PathVariable long id_project) {
        List<TaskPojo> listTask = taskService.findAllTasks(id_project);
        if(listTask==null||listTask.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listTask, HttpStatus.OK);
    }

    @GetMapping("/{id_task}")
    public ResponseEntity<TaskPojo> findById(@PathVariable long id_project, @PathVariable long id_task) {
        TaskPojo taskPojo = taskService.findById(id_project, id_task);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<TaskPojo> createTask(@PathVariable long id_project, @RequestBody TaskPojo pojo) {
        return new ResponseEntity<>(taskService.createTask(id_project, pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_task}")
    public ResponseEntity<TaskPojo> updateTask(@PathVariable long id_project, @PathVariable long id_task, @RequestBody TaskPojo pojo) {
        TaskPojo taskPojo = taskService.updateTask(id_project, id_task, pojo);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @DeleteMapping("/{id_task}")
    public ResponseEntity<Boolean> deleteTask(@PathVariable long id_project, @PathVariable long id_task) {
        return new ResponseEntity<>(taskService.deleteTask(id_project, id_task), HttpStatus.NO_CONTENT);
    }

    @DeleteMapping("/deleteCompletedTasks")
    public ResponseEntity<Boolean> deleteCompletedTask(@PathVariable long id_project) {
        if(taskService.deleteCompletedTask(id_project))
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}
