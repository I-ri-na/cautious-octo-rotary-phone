package com.ssau.backend.dto;

import com.ssau.backend.entity.*;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Getter
@Setter
public class GroupidPojo {

    private long id_groupid;
    private int number_group;
    private Specialty specialty;
    private List<StudentPojo> students;
    private List<LearningPlanPojo> learningplans;

    public static GroupidPojo fromEntity(Groupid groupid){
        GroupidPojo pojo = new GroupidPojo();
        pojo.setId_groupid(groupid.getId_groupid());
        pojo.setNumber_group(groupid.getNumber_group());
        pojo.setSpecialty(groupid.getSpecialty());

        List<StudentPojo> students = new ArrayList<>();
        pojo.setStudents(students);
        for (Student student : groupid.getStudents())
            students.add(StudentPojo.fromEntity(student));

        List<LearningPlanPojo> learningplans = new ArrayList<>();
        pojo.setLearningplans(learningplans);
        for (LearningPlan learningplan : groupid.getLearningplans())
            learningplans.add(LearningPlanPojo.fromEntity(learningplan));

        return pojo;
    }

    public static Groupid toEntity(GroupidPojo pojo){
        Groupid groupid = new Groupid();
        groupid.setId_groupid(pojo.getId_groupid());
        groupid.setNumber_group(pojo.getNumber_group());
        groupid.setSpecialty(pojo.getSpecialty());

        List<Student> students = new ArrayList<>();
        groupid.setStudents(students);

        List<LearningPlan> learningplans = new ArrayList<>();
        groupid.setLearningplans(learningplans);

        return groupid;
    }
}
