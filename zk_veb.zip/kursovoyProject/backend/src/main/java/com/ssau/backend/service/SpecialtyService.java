package com.ssau.backend.service;

import com.ssau.backend.dto.SpecialtyPojo;
import com.ssau.backend.entity.Specialty;
import com.ssau.backend.repository.SpecialtyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class SpecialtyService {
    private final SpecialtyRepository specialtyRepository;

    public List<SpecialtyPojo> findAll(String search) {
        List<SpecialtyPojo> result = new ArrayList<>();
        for (Specialty specialty : specialtyRepository.findAll())
            result.add(SpecialtyPojo.fromEntity(specialty));
        return result;
    }

    public SpecialtyPojo findById(long id_specialty) {
        return specialtyRepository.findById(id_specialty).map(SpecialtyPojo::fromEntity).orElse(null);
    }

    public SpecialtyPojo create(SpecialtyPojo pojo) {
        Specialty specialty = SpecialtyPojo.toEntity(pojo);
        return SpecialtyPojo.fromEntity(specialtyRepository.save(specialty));
    }

    public SpecialtyPojo update(long id_specialty, SpecialtyPojo pojo) {
        SpecialtyPojo byId = findById(id_specialty);

        if (byId != null) {
            Specialty specialty = SpecialtyPojo.toEntity(byId);
            specialty.setCode_specialty(pojo.getCode_specialty());
            specialty.setName_specialty(pojo.getName_specialty());
            specialty.setFio_headofspecialty(pojo.getFio_headofspecialty());
            specialty.setNumber_headofspecialty(pojo.getNumber_headofspecialty());
            return SpecialtyPojo.fromEntity(specialtyRepository.save(specialty));
        } else {
            return null;
        }
    }

    public boolean delete(long id_specialty) {
        if (specialtyRepository.existsById(id_specialty)) {
            specialtyRepository.deleteById(id_specialty);
            return true;
        } else return false;
    }
}
