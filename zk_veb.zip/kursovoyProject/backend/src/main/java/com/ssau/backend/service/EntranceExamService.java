package com.ssau.backend.service;

import com.ssau.backend.dto.EntranceExamPojo;
import com.ssau.backend.dto.GroupidPojo;
import com.ssau.backend.dto.LearningPlanPojo;
import com.ssau.backend.dto.StudentPojo;
import com.ssau.backend.entity.EntranceExam;

import com.ssau.backend.entity.LearningPlan;
import com.ssau.backend.repository.EntranceExamRepository;
import com.ssau.backend.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EntranceExamService {

    private final EntranceExamRepository entranceexamRepository;
    private final StudentRepository studentRepository;

    public List<EntranceExamPojo> findAllExams(long id_student) {
        if(id_student!=0) {
            StudentPojo project = StudentPojo.fromEntity(studentRepository.findById(id_student).orElseThrow());
            return project.getEntranceexams();
        }
        else {
            List<EntranceExamPojo> result = new ArrayList<>();
            for (EntranceExam entranceExam : entranceexamRepository.findAll())
                result.add(EntranceExamPojo.fromEntity(entranceExam));
            return result;
        }
    }

    public EntranceExamPojo findById(long id_student, long id_entranceexam) {
        EntranceExam task = entranceexamRepository.findById(id_entranceexam).orElseThrow();
        if (task.getStudent().getId_student() == id_student)
            return EntranceExamPojo.fromEntity(task);
        else
            return null;
    }

    public EntranceExamPojo create(long id_student, EntranceExamPojo pojo) {
        EntranceExam task = EntranceExamPojo.toEntity(pojo);
        task.setStudent(studentRepository.findById(id_student).orElseThrow());
        return EntranceExamPojo.fromEntity(entranceexamRepository.save(task));
    }

    public EntranceExamPojo update(long id_student, long id_entranceexam, EntranceExamPojo pojo) {
        EntranceExamPojo taskPojo = findById(id_student, id_entranceexam);
        if (taskPojo != null) {
            EntranceExam entranceexam = EntranceExamPojo.toEntity(taskPojo);
            entranceexam.setName_exam(pojo.getName_exam());
            entranceexam.setResult_exam(pojo.getResult_exam());
            entranceexam.setStudent(studentRepository.findById(id_student).orElseThrow());
            return EntranceExamPojo.fromEntity(entranceexamRepository.save(entranceexam));
        } else
            return null;
    }

    public boolean delete(long id_student, long id_entranceexam) {
        if (findById(id_student, id_entranceexam) != null) {
            entranceexamRepository.deleteById(id_entranceexam);
            return true;
        } else
            return false;
    }

}