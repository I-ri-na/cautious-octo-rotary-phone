package com.ssau.backend.service;

import com.ssau.backend.dto.GroupidPojo;
import com.ssau.backend.dto.SpecialtyPojo;
import com.ssau.backend.dto.StudentPojo;
import com.ssau.backend.entity.Groupid;
import com.ssau.backend.entity.Student;
import com.ssau.backend.repository.GroupidRepository;
import com.ssau.backend.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {
    private final StudentRepository studentRepository;
    private final GroupidRepository groupidRepository;

    public List<StudentPojo> findAllStudents(long id_group) {
        if(id_group!=0) {
            GroupidPojo project = GroupidPojo.fromEntity(groupidRepository.findById(id_group).orElseThrow());
            return project.getStudents();
        }
        else {
            List<StudentPojo> result = new ArrayList<>();
            for (Student student : studentRepository.findAll())
                result.add(StudentPojo.fromEntity(student));
            return result;
        }
    }

    public StudentPojo findById(long id_groupid, long id_student) {
        Student task = studentRepository.findById(id_student).orElseThrow();
        if(task.getGroupid().getId_groupid()==id_groupid)
            return StudentPojo.fromEntity(task);
        else
            return null;
    }

    public StudentPojo create(long id_group, StudentPojo pojo) {
        Student task = StudentPojo.toEntity(pojo);
        task.setGroupid(groupidRepository.findById(id_group).orElseThrow());
        return StudentPojo.fromEntity(studentRepository.save(task));
    }

    public StudentPojo update(long id_group, long id_student, StudentPojo pojo) {
        StudentPojo taskPojo = findById(id_group, id_student);
        if(taskPojo!=null) {
            Student student = StudentPojo.toEntity(taskPojo);
            student.setNumber_student(pojo.getNumber_student());
            student.setFio(pojo.getFio());
            student.setDate_birthday(pojo.getDate_birthday());
            student.setDate_admission(pojo.getDate_admission());
            student.setNumber(pojo.getNumber());
            student.setGroupid(groupidRepository.findById(id_group).orElseThrow());
            return StudentPojo.fromEntity(studentRepository.save(student));
        }
        else
            return null;
    }
    public boolean delete(long id_group, long id_student) {
        if (findById(id_group, id_student)!=null)
        {
            studentRepository.deleteById(id_student);
            return true;
        }
        else
            return false;
    }

}
