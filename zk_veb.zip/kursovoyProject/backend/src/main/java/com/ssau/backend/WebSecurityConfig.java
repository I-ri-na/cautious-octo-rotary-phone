package com.ssau.backend;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import java.util.List;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig {
    @Value("${security.logins}")
    private List<String> login;
    @Value("${security.passwords}")
    private List<String> password;
    @Value("${security.roles}")
    private List<String> role;
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests((requests) -> requests
//                        .requestMatchers("/", "/home", "/login").permitAll()
//                        .requestMatchers("/api/**").authenticated()
                        .requestMatchers(HttpMethod.POST, "/api/specialty").hasRole(role.get(1))
                        .requestMatchers(HttpMethod.PUT, "/api/specialty/{id_specialty}").hasRole(role.get(1))
                        .requestMatchers(HttpMethod.DELETE, "/api/specialty/{id_specialty}").hasRole(role.get(1))
//                        .requestMatchers(HttpMethod.POST, "/api/specialty/{id_specialty}/groupid").hasRole(role.get(1))
//                        .requestMatchers(HttpMethod.PUT, "/api/specialty/{id_specialty}/groupid/{id_groupid}").hasRole(role.get(1))
//                        .requestMatchers(HttpMethod.DELETE, "/api/specialty/{id_specialty}/groupid/{id_groupid}").hasRole(role.get(1))
                        .requestMatchers(HttpMethod.POST, "/api/groupid/{id_groupid}/learningplan").hasRole(role.get(1))
                        .requestMatchers(HttpMethod.PUT, "/api/groupid/{id_groupid}/learningplan/{id_learningplan}").hasRole(role.get(1))
                        .requestMatchers(HttpMethod.DELETE, "/api/groupid/{id_groupid}/learningplan/{id_learningplan}").hasRole(role.get(1))
//
                        .anyRequest().permitAll()).httpBasic();
        return http.build();
    }


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user =
                User.withUsername(login.get(0))
                        .password(passwordEncoder().encode(password.get(0)))
                        .roles("USER")
                        .build();
        UserDetails admin =
                User.withUsername(login.get(1))
                        .password(passwordEncoder().encode(password.get(1)))
                        .roles("ADMIN")
                        .build();

        return new InMemoryUserDetailsManager(user, admin);
    }
}
