package com.ssau.backend.controller;

import com.ssau.backend.dto.GroupidPojo;
import com.ssau.backend.dto.TaskPojo;
import com.ssau.backend.service.GroupidService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/specialty/{id_specialty}/groupid")
public class GroupidController {
    @Autowired
    private GroupidService groupidService;

    @GetMapping()
    public ResponseEntity<List<GroupidPojo>> findAllGroupByIdSpecialty(@PathVariable long id_specialty) {
        List<GroupidPojo> listTask = groupidService.findAllGroups(id_specialty);
        if(listTask==null||listTask.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listTask, HttpStatus.OK);
    }
    @GetMapping("/{id_groupid}")
    public ResponseEntity<GroupidPojo> findById(@PathVariable long id_specialty, @PathVariable long id_groupid) {
        GroupidPojo taskPojo = groupidService.findById(id_specialty, id_groupid);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<GroupidPojo> createTask(@PathVariable long id_specialty, @RequestBody GroupidPojo pojo) {
        return new ResponseEntity<>(groupidService.create(id_specialty, pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_groupid}")
    public ResponseEntity<GroupidPojo> updateTask(@PathVariable long id_specialty, @PathVariable long id_groupid, @RequestBody GroupidPojo pojo) {
        GroupidPojo taskPojo = groupidService.update(id_specialty, id_groupid, pojo);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @DeleteMapping("/{id_groupid}")
    public ResponseEntity<Boolean> deleteTask(@PathVariable long id_specialty, @PathVariable long id_groupid) {
        return new ResponseEntity<>(groupidService.delete(id_specialty, id_groupid), HttpStatus.NO_CONTENT);
    }

}

//{
//        "number_group": "6101"
//}

