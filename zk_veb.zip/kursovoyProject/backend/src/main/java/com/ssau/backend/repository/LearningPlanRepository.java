package com.ssau.backend.repository;

import com.ssau.backend.entity.LearningPlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LearningPlanRepository  extends JpaRepository<LearningPlan, Long> {
}
