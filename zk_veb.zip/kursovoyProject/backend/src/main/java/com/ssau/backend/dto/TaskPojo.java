package com.ssau.backend.dto;


import com.ssau.backend.entity.Task;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class TaskPojo {
    private long id_task;
    private String name_task;
    private String description_of_the_task;
    private Date planned_completion_date_task;
    private boolean completion_flag_task;

    public static TaskPojo fromEntity(Task task){
        TaskPojo pojo = new TaskPojo();
        pojo.setId_task(task.getId_task());
        pojo.setName_task(task.getName_Task());
        pojo.setDescription_of_the_task(task.getDescription_of_the_task());
        pojo.setPlanned_completion_date_task(task.getPlanned_completion_date_task());
        pojo.setCompletion_flag_task(task.isCompletion_flag_task());
        return pojo;
    }

    public static Task toEntity(TaskPojo pojo){
        Task task = new Task();
        task.setId_task(pojo.getId_task());
        task.setName_Task(pojo.getName_task());
        task.setDescription_of_the_task(pojo.getDescription_of_the_task());
        task.setPlanned_completion_date_task(pojo.getPlanned_completion_date_task());
        task.setCompletion_flag_task(pojo.isCompletion_flag_task());
        return task;
    }
}
