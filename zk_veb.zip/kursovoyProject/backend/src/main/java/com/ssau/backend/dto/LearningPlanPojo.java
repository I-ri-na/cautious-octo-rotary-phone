package com.ssau.backend.dto;

import com.ssau.backend.entity.Groupid;
import com.ssau.backend.entity.LearningPlan;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LearningPlanPojo {

    private long id_learningplan;
    private int code_discipline;
    private int number_semester;
    private int count_hours;
    private Groupid groupid;

    public static LearningPlanPojo fromEntity(LearningPlan learningplan){
        LearningPlanPojo pojo = new LearningPlanPojo();
        pojo.setId_learningplan(learningplan.getId_learningplan());
        pojo.setCode_discipline(learningplan.getCode_discipline());
        pojo.setNumber_semester(learningplan.getNumber_semester());
        pojo.setCount_hours(learningplan.getCount_hours());
        pojo.setGroupid(learningplan.getGroupid());
        return pojo;
    }

    public static LearningPlan toEntity(LearningPlanPojo pojo){
        LearningPlan learningplan = new LearningPlan();
        learningplan.setId_learningplan(pojo.getId_learningplan());
        learningplan.setCode_discipline(pojo.getCode_discipline());
        learningplan.setNumber_semester(pojo.getNumber_semester());
        learningplan.setCount_hours(pojo.getCount_hours());
        learningplan.setGroupid(pojo.getGroupid());
        return learningplan;
    }
}
