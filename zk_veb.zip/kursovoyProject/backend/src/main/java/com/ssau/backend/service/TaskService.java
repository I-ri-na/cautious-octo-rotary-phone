package com.ssau.backend.service;


import com.ssau.backend.dto.ProjectPojo;
import com.ssau.backend.dto.TaskPojo;
import com.ssau.backend.entity.Project;
import com.ssau.backend.entity.Task;
import com.ssau.backend.repository.ProjectRepository;

import com.ssau.backend.repository.TaskRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TaskService {
    private final TaskRepository taskRepository;
    private final ProjectRepository projectRepository;

    public List<TaskPojo> findAllTasks(long id_project) {

        ProjectPojo project = ProjectPojo.fromEntity(projectRepository.findById(id_project).orElseThrow());
        return project.getTasks();
    }

    public TaskPojo findById(long id_project, long id_task) {
        Task task = taskRepository.findById(id_task).orElseThrow();
        if(task.getProject().getId_project()==id_project)
            return TaskPojo.fromEntity(task);
        else
            return null;
    }

    public TaskPojo createTask(long id_project, TaskPojo pojo) {
        Task task = TaskPojo.toEntity(pojo);
        task.setProject(projectRepository.findById(id_project).orElseThrow());
        return TaskPojo.fromEntity(taskRepository.save(task));
    }

    public TaskPojo updateTask(long id_project, long id_task, TaskPojo pojo) {
        TaskPojo taskPojo = findById(id_project, id_task);
        if(taskPojo!=null) {
            Task task1 = TaskPojo.toEntity(taskPojo);
            task1.setName_Task(pojo.getName_task());
            task1.setDescription_of_the_task(pojo.getDescription_of_the_task());
            task1.setPlanned_completion_date_task(pojo.getPlanned_completion_date_task());
            task1.setCompletion_flag_task(pojo.isCompletion_flag_task());
            task1.setProject(projectRepository.findById(id_project).orElseThrow());
            return TaskPojo.fromEntity(taskRepository.save(task1));
        }
        else
            return null;
    }
    public boolean deleteTask(long id_project, long id_task) {
        if (findById(id_project, id_task)!=null)
        {
            taskRepository.deleteById(id_task);
            return true;
        }
        else
            return false;
    }

    @Transactional
    public boolean deleteCompletedTask(long id_project) {
        if (projectRepository.existsById(id_project))
        {
            Project project = projectRepository.getReferenceById(id_project);
            for (Task task : project.getTasks()){
                if(task.isCompletion_flag_task())
                    taskRepository.deleteById(task.getId_task());
            }
            return true;
        }
        else
            return false;
    }
}
