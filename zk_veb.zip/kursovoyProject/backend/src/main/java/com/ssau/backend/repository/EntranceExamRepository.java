package com.ssau.backend.repository;

import com.ssau.backend.entity.EntranceExam;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntranceExamRepository  extends JpaRepository<EntranceExam, Long> {
}
