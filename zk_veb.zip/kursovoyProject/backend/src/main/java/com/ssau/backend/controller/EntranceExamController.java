package com.ssau.backend.controller;

import com.ssau.backend.dto.EntranceExamPojo;
import com.ssau.backend.service.EntranceExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/student/{id_student}/entranceexam")
public class EntranceExamController {
    @Autowired
    private EntranceExamService entranceExamService;

    @GetMapping()
    public ResponseEntity<List<EntranceExamPojo>> findAllExamsByIdStudent(@PathVariable long id_student) {
        List<EntranceExamPojo> listTask = entranceExamService.findAllExams(id_student);
        if(listTask==null||listTask.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listTask, HttpStatus.OK);
    }

    @GetMapping("/{id_entranceexam}")
    public ResponseEntity<EntranceExamPojo> findById(@PathVariable long id_student, @PathVariable long id_entranceexam) {
        EntranceExamPojo taskPojo = entranceExamService.findById(id_student, id_entranceexam);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<EntranceExamPojo> createTask(@PathVariable long id_student, @RequestBody EntranceExamPojo pojo) {
        return new ResponseEntity<>(entranceExamService.create(id_student, pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_entranceexam}")
    public ResponseEntity<EntranceExamPojo> updateTask(@PathVariable long id_student, @PathVariable long id_entranceexam, @RequestBody EntranceExamPojo pojo) {
        EntranceExamPojo taskPojo = entranceExamService.update(id_student, id_entranceexam, pojo);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @DeleteMapping("/{id_entranceexam}")
    public ResponseEntity<Boolean> deleteTask(@PathVariable long id_student, @PathVariable long id_entranceexam) {
        return new ResponseEntity<>(entranceExamService.delete(id_student, id_entranceexam), HttpStatus.NO_CONTENT);
    }
}

//{
//        "name_exam": "exam1",
//        "result_exam": "3"
//}
