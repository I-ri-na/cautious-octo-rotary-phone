package com.ssau.backend.dto;

import com.ssau.backend.entity.Project;
import com.ssau.backend.entity.Task;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class ProjectPojo {
    private long id_project;
    private String name_project;
    private String description_of_the_project;
    private Date start_date_project;
    private Date completion_date_project;
    private List<TaskPojo> tasks;


    public static ProjectPojo fromEntity(Project project){
        ProjectPojo pojo = new ProjectPojo();
        pojo.setId_project(project.getId_project());
        pojo.setName_project(project.getName_project());
        pojo.setDescription_of_the_project(project.getDescription_of_the_project());
        pojo.setStart_date_project(project.getStart_date_project());
        pojo.setCompletion_date_project(project.getCompletion_date_project());

        List<TaskPojo> tasks = new ArrayList<>();
        pojo.setTasks(tasks);
        for (Task task : project.getTasks())
            tasks.add(TaskPojo.fromEntity(task));

        return pojo;
    }

    public static Project toEntity(ProjectPojo pojo){
        Project project = new Project();
        project.setId_project(pojo.getId_project());
        project.setName_project(pojo.getName_project());
        project.setDescription_of_the_project(pojo.getDescription_of_the_project());
        project.setStart_date_project(pojo.getStart_date_project());
        project.setCompletion_date_project(pojo.getCompletion_date_project());

        List<Task> tasks = new ArrayList<>();
        project.setTasks(tasks);

        return project;
    }
}
