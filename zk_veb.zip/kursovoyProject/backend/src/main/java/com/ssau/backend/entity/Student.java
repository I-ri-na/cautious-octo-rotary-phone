package com.ssau.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "student", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = "number_student"),@UniqueConstraint(columnNames = "number"),@UniqueConstraint(columnNames = {"fio","date_birthday"})})
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_student;

    private int number_student;

    private String fio;

    @Temporal(value = TemporalType.DATE)
    private Date date_birthday;

    private int date_admission;

    private String number;

    @JsonIgnore
    @OneToMany(mappedBy = "student", fetch = FetchType.LAZY)
    private List<Document> documents;

    @JsonIgnore
    @OneToMany(mappedBy = "student", fetch = FetchType.LAZY)
    private List<EntranceExam> entranceexams;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_groupid", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    private Groupid groupid;

}
