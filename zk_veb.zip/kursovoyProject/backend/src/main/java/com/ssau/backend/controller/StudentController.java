package com.ssau.backend.controller;

import com.ssau.backend.dto.StudentPojo;
import com.ssau.backend.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/groupid/{id_groupid}/student")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @GetMapping()
    public ResponseEntity<List<StudentPojo>> findAllStudentsByIdGroup(@PathVariable long id_groupid) {
        List<StudentPojo> listTask = studentService.findAllStudents(id_groupid);
        if(listTask==null||listTask.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listTask, HttpStatus.OK);
    }

    @GetMapping("/{id_student}")
    public ResponseEntity<StudentPojo> findById(@PathVariable long id_groupid, @PathVariable long id_student) {
        StudentPojo taskPojo = studentService.findById(id_groupid, id_student);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<StudentPojo> createTask(@PathVariable long id_groupid, @RequestBody StudentPojo pojo) {
        return new ResponseEntity<>(studentService.create(id_groupid, pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_student}")
    public ResponseEntity<StudentPojo> updateTask(@PathVariable long id_groupid, @PathVariable long id_student, @RequestBody StudentPojo pojo) {
        StudentPojo taskPojo = studentService.update(id_groupid, id_student, pojo);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @DeleteMapping("/{id_student}")
    public ResponseEntity<Boolean> deleteTask(@PathVariable long id_groupid, @PathVariable long id_student) {
        return new ResponseEntity<>(studentService.delete(id_groupid, id_student), HttpStatus.NO_CONTENT);
    }

}

//{
//        "number_student": "01218",
//        "fio": "fio1",
//        "date_birthday": "2002-01-19",
//        "date_admission": "2020",
//        "number": "89270165638"
//}
