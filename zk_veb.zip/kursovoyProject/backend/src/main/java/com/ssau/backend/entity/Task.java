package com.ssau.backend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "task", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = {"id_project","name"}) })
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_task;

    private String name;

    private String description_of_the_task;

    @Temporal(value = TemporalType.DATE)
    private Date planned_completion_date_task;

    private boolean completion_flag_task;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_project", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    private Project project;

    public String getName_Task() {
        return name;
    }

    public void setName_Task(String name) {
        this.name = name;
    }
}
