package com.ssau.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "specialty", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = "code_specialty"), @UniqueConstraint(columnNames = "name_specialty")})
public class Specialty {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_specialty;

    private String code_specialty;

    private String name_specialty;

    private String fio_headofspecialty;

    private String number_headofspecialty;

    @JsonIgnore
    @OneToMany(mappedBy = "specialty", fetch = FetchType.LAZY)
    private List<Groupid> groupids;

}