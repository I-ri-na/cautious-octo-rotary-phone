package com.ssau.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "groupid", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = "number_group")})
public class Groupid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_groupid;

    private int number_group;

    @JsonIgnore
    @OneToMany(mappedBy = "groupid", fetch = FetchType.LAZY)
    private List<Student> students;

    @JsonIgnore
    @OneToMany(mappedBy = "groupid", fetch = FetchType.LAZY)
    private List<LearningPlan> learningplans;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_specialty", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    private Specialty specialty;

}
