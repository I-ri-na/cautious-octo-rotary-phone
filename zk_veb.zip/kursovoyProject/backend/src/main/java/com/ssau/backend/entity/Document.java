package com.ssau.backend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "document", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = {"name_document","id_student"})})
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_document;

    private String name_document;

    private boolean have_document;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_student", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    private Student student;

}
