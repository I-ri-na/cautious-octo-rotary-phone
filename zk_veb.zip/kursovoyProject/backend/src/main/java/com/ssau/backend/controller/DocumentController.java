package com.ssau.backend.controller;

import com.ssau.backend.dto.DocumentPojo;
import com.ssau.backend.service.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/student/{id_student}/document")
public class DocumentController {
    @Autowired
    private DocumentService documentService;

    @GetMapping()
    public ResponseEntity<List<DocumentPojo>> findAllDocumentsByIdStudent(@PathVariable long id_student) {
        List<DocumentPojo> listTask = documentService.findAllDocuments(id_student);
        if(listTask==null||listTask.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listTask, HttpStatus.OK);
    }

    @GetMapping("/{id_document}")
    public ResponseEntity<DocumentPojo> findById(@PathVariable long id_student, @PathVariable long id_document) {
        DocumentPojo taskPojo = documentService.findById(id_student, id_document);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<DocumentPojo> createTask(@PathVariable long id_student, @RequestBody DocumentPojo pojo) {
        return new ResponseEntity<>(documentService.create(id_student, pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_document}")
    public ResponseEntity<DocumentPojo> updateTask(@PathVariable long id_student, @PathVariable long id_document, @RequestBody DocumentPojo pojo) {
        DocumentPojo taskPojo = documentService.update(id_student, id_document, pojo);
        if(taskPojo==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(taskPojo, HttpStatus.OK);
    }

    @DeleteMapping("/{id_document}")
    public ResponseEntity<Boolean> deleteTask(@PathVariable long id_student, @PathVariable long id_document) {
        return new ResponseEntity<>(documentService.delete(id_student, id_document), HttpStatus.NO_CONTENT);
    }
}


//{
//        "name_document": "doc1",
//        "have_document": "true"
//}
