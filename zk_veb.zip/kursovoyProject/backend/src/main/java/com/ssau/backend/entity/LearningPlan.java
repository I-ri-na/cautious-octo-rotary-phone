package com.ssau.backend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "learningplan", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = {"id_groupid","code_discipline","number_semester"})})
public class LearningPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_learningplan;

    private int code_discipline;

    private int number_semester;

    private int count_hours;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_groupid", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    private Groupid groupid;

}
