package com.ssau.backend.repository;

import com.ssau.backend.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    @Query(value = "select * from public.project where name ilike %:name% or description_of_the_project ilike %:name%", nativeQuery = true)
    List<Project> selectByName(String name);
}
