package com.ssau.backend.dto;

import com.ssau.backend.entity.Groupid;
import com.ssau.backend.entity.Specialty;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class SpecialtyPojo {

    private long id_specialty;
    private String code_specialty;
    private String name_specialty;
    private String fio_headofspecialty;
    private String number_headofspecialty;
    private List<GroupidPojo> groupids;

    public static SpecialtyPojo fromEntity(Specialty specialty){
        SpecialtyPojo pojo = new SpecialtyPojo();
        pojo.setId_specialty(specialty.getId_specialty());
        pojo.setCode_specialty(specialty.getCode_specialty());
        pojo.setName_specialty(specialty.getName_specialty());
        pojo.setFio_headofspecialty(specialty.getFio_headofspecialty());
        pojo.setNumber_headofspecialty(specialty.getNumber_headofspecialty());

        List<GroupidPojo> groupids = new ArrayList<>();
        pojo.setGroupids(groupids);
        for (Groupid groupid : specialty.getGroupids())
            groupids.add(GroupidPojo.fromEntity(groupid));
        return pojo;
    }

    public static Specialty toEntity(SpecialtyPojo pojo){
        Specialty specialty = new Specialty();
        specialty.setId_specialty(pojo.getId_specialty());
        specialty.setCode_specialty(pojo.getCode_specialty());
        specialty.setName_specialty(pojo.getName_specialty());
        specialty.setFio_headofspecialty(pojo.getFio_headofspecialty());
        specialty.setNumber_headofspecialty(pojo.getNumber_headofspecialty());

        List<Groupid> groupids = new ArrayList<>();
        specialty.setGroupids(groupids);

        return specialty;
    }
}
