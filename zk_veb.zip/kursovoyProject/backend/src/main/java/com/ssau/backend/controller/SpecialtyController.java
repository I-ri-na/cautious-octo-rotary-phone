package com.ssau.backend.controller;

import com.ssau.backend.dto.SpecialtyPojo;
import com.ssau.backend.service.SpecialtyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/specialty")
public class SpecialtyController {
    @Autowired
    private SpecialtyService specialtyService;

    @GetMapping(params = {"search"})
    public ResponseEntity<List<SpecialtyPojo>> findAll(@RequestParam String search) {
        List<SpecialtyPojo> list = specialtyService.findAll(search);
        if (list.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @GetMapping("/{id_specialty}")
    public ResponseEntity<SpecialtyPojo> findById(@PathVariable long id_specialty) {
        SpecialtyPojo pojo = specialtyService.findById(id_specialty);
        if (pojo == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(pojo, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<SpecialtyPojo> create(@RequestBody SpecialtyPojo pojo) {
        return new ResponseEntity<>(specialtyService.create(pojo), HttpStatus.CREATED);
    }

    @PutMapping("/{id_specialty}")
    public ResponseEntity<SpecialtyPojo> update(@RequestBody SpecialtyPojo pojo, @PathVariable long id_specialty) {
        SpecialtyPojo pojo1 = specialtyService.update(id_specialty, pojo);
        if (pojo1 == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(pojo1, HttpStatus.OK);
    }

    @DeleteMapping("/{id_specialty}")
    public ResponseEntity<Boolean> delete(@PathVariable long id_specialty) {
        if (specialtyService.delete(id_specialty))
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

//{
//        "code_specialty": "spec00",
//        "name_specialty": "namespec00",
//        "fio_headofspecialty": "fio00",
//        "number_headofspecialty": "89279876540"
//}