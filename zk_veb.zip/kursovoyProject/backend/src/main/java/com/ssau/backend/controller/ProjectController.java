package com.ssau.backend.controller;


import com.ssau.backend.dto.ProjectPojo;
import com.ssau.backend.dto.TaskPojo;
import com.ssau.backend.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/project")
public class ProjectController {
    @Autowired
    private ProjectService projectService;

    @GetMapping(params = {"search"})
    public ResponseEntity<List<ProjectPojo>> findAll(@RequestParam String search) {
        List<ProjectPojo> listProject = projectService.findAll(search);
        if (listProject.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(listProject, HttpStatus.OK);
    }

    @GetMapping("/{id_project}")
    public ResponseEntity<ProjectPojo> findById(@PathVariable long id_project) {
        ProjectPojo project = projectService.findById(id_project);
        if (project == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(project, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<ProjectPojo> createProject(@RequestBody ProjectPojo project) {
        return new ResponseEntity<>(projectService.createProject(project), HttpStatus.CREATED);
    }

    @PutMapping("/{id_project}")
    public ResponseEntity<ProjectPojo> updateProject(@RequestBody ProjectPojo project, @PathVariable long id_project) {
        ProjectPojo project1 = projectService.updateProject(id_project, project);
        if (project1 == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(project1, HttpStatus.OK);
    }

    @DeleteMapping("/{id_project}")
    public ResponseEntity<Boolean> deleteProject(@PathVariable long id_project) {
        if (projectService.deleteProject(id_project))
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/findHashMap")
    public ResponseEntity<HashMap<Long, Integer>> findHashMap() {
        HashMap<Long, Integer> hashMap = projectService.findHashMap();
        if (hashMap == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(hashMap, HttpStatus.OK);
    }
}
