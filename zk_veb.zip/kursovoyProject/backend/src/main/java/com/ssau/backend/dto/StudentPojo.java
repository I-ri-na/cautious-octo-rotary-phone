package com.ssau.backend.dto;

import com.ssau.backend.entity.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Getter
@Setter
public class StudentPojo {

    private long id_student;
    private int number_student;
    private String fio;
    private Date date_birthday;
    private int date_admission;
    private String number;
    private Groupid groupid;
    private List<DocumentPojo> documents;
    private List<EntranceExamPojo> entranceexams;

    public static StudentPojo fromEntity(Student student){
        StudentPojo pojo = new StudentPojo();
        pojo.setId_student(student.getId_student());
        pojo.setNumber_student(student.getNumber_student());
        pojo.setFio(student.getFio());
        pojo.setDate_birthday(student.getDate_birthday());
        pojo.setDate_admission(student.getDate_admission());
        pojo.setNumber(student.getNumber());
        pojo.setGroupid(student.getGroupid());

        List<DocumentPojo> documents = new ArrayList<>();
        pojo.setDocuments(documents);
        for (Document document : student.getDocuments())
            documents.add(DocumentPojo.fromEntity(document));

        List<EntranceExamPojo> entranceexams = new ArrayList<>();
        pojo.setEntranceexams(entranceexams);
        for (EntranceExam entranceexam : student.getEntranceexams())
            entranceexams.add(EntranceExamPojo.fromEntity(entranceexam));

        return pojo;
    }

    public static Student toEntity(StudentPojo pojo){
        Student student = new Student();
        student.setId_student(pojo.getId_student());
        student.setNumber_student(pojo.getNumber_student());
        student.setFio(pojo.getFio());
        student.setDate_birthday(pojo.getDate_birthday());
        student.setDate_admission(pojo.getDate_admission());
        student.setNumber(pojo.getNumber());
        student.setGroupid(pojo.getGroupid());

        List<Document> documents = new ArrayList<>();
        student.setDocuments(documents);

        List<EntranceExam> entranceexams = new ArrayList<>();
        student.setEntranceexams(entranceexams);

        return student;
    }
}
