package com.ssau.backend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "project", schema = "public", uniqueConstraints = { @UniqueConstraint(columnNames = "name") })
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_project;

    private String name;

    private String description_of_the_project;

    //@DateTimeFormat(pattern = "dd/MM/yyyy")
    @Temporal(value = TemporalType.DATE)
    private Date start_date_project;

    //@DateTimeFormat(pattern = "dd/MM/yyyy")
    @Temporal(value = TemporalType.DATE)
    private Date completion_date_project;

    @OneToMany(mappedBy = "project", fetch = FetchType.LAZY)
    private List<Task> tasks;

    public String getName_project() {
        return name;
    }

    public void setName_project(String name) {
        this.name = name;
    }
}
