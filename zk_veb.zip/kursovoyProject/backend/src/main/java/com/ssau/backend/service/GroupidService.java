package com.ssau.backend.service;

import com.ssau.backend.dto.GroupidPojo;
import com.ssau.backend.dto.SpecialtyPojo;
import com.ssau.backend.entity.Groupid;
import com.ssau.backend.entity.Specialty;
import com.ssau.backend.repository.GroupidRepository;
import com.ssau.backend.repository.ProjectRepository;
import com.ssau.backend.repository.SpecialtyRepository;
import com.ssau.backend.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class GroupidService {

    private final GroupidRepository groupidRepository;
    private final SpecialtyRepository specialtyRepository;

    public List<GroupidPojo> findAllGroups(long id_specialty) {
        if(id_specialty!=0) {
            SpecialtyPojo pojo = SpecialtyPojo.fromEntity(specialtyRepository.findById(id_specialty).orElseThrow());
            return pojo.getGroupids();
        }
        else {
            List<GroupidPojo> result = new ArrayList<>();
            for (Groupid groupid : groupidRepository.findAll())
                result.add(GroupidPojo.fromEntity(groupid));
            return result;
        }
    }

    public GroupidPojo findById(long id_specialty, long id_group) {

        Groupid groupid = groupidRepository.findById(id_group).orElseThrow();
        if(id_specialty==0)
            return GroupidPojo.fromEntity(groupid);
        else {
            if (groupid.getSpecialty().getId_specialty() == id_specialty)
                return GroupidPojo.fromEntity(groupid);
            else
                return null;
        }
    }

    public GroupidPojo create(long id_specialty, GroupidPojo pojo) {
        Groupid task = GroupidPojo.toEntity(pojo);
        task.setSpecialty(specialtyRepository.findById(id_specialty).orElseThrow());
        return GroupidPojo.fromEntity(groupidRepository.save(task));
    }

    public GroupidPojo update(long id_specialty, long id_group, GroupidPojo pojo) {
        GroupidPojo taskPojo = findById(id_specialty, id_group);
        if (taskPojo != null) {
            Groupid groupid = GroupidPojo.toEntity(taskPojo);
            groupid.setNumber_group(pojo.getNumber_group());
            groupid.setSpecialty(pojo.getSpecialty());
            System.out.println(pojo.getSpecialty());
            return GroupidPojo.fromEntity(groupidRepository.save(groupid));
        } else
            return null;
    }

    public boolean delete(long id_specialty, long id_group) {
        if (findById(id_specialty, id_group) != null) {
            groupidRepository.deleteById(id_group);
            return true;
        } else
            return false;
    }
}