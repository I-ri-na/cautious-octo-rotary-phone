package com.ssau.backend.repository;

import com.ssau.backend.entity.Groupid;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupidRepository  extends JpaRepository<Groupid, Long> {
}
