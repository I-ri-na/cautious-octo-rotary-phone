export const environment = {
    apiUrl: ""
};
