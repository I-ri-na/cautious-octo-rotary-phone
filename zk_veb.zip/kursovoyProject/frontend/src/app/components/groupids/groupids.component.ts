import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddGroupidComponent } from 'src/app/components/update-groupid/add-groupid.component';
import { IGroupid } from 'src/app/models/groupid';
import { GroupidService } from 'src/app/service/groupid.service';

@Component({
  selector: 'app-groupids',
  templateUrl: './groupids.component.html',
  styleUrls: ['./groupids.component.css']
})
export class GroupidsComponent implements OnInit {

  groupids: IGroupid[]

  constructor(
    private groupidService : GroupidService,
    private router: Router,
    private modalService: NgbModal,
    ) {}

  ngOnInit(): void {
    this.groupidService.getAll(0).subscribe(
      {
        next: groupids => {this.groupids = groupids},
        error: (error) => {}
      }
    )
  }

  openUpdateForm(id_groupid: number, index: number): void {
    let groupid = this.groupids[index];
    const groupidModalBox = this.modalService.open(AddGroupidComponent, {centered: true});
    groupidModalBox.componentInstance.id_groupid = groupid.id_groupid;
    groupidModalBox.componentInstance.number_group = groupid.number_group;
    groupidModalBox.componentInstance.specialty = groupid.specialty;
    groupidModalBox.componentInstance.title = "Изменить группу";
    groupidModalBox.result.then((groupid : IGroupid) => {
          if (!groupid) return;
          this.groupidService.update(groupid.specialty.id_specialty,id_groupid,groupid).subscribe({
            next:(reponse) => {
              this.groupids[index] = reponse;
            },
            error:(error) => alert(error)
          })
        }).catch((error) => {});
      }

  openGroupidForm(): void {
    const groupidModalBox = this.modalService.open(AddGroupidComponent, {centered: true});
    groupidModalBox.componentInstance.title = "Добавить группу";
    groupidModalBox.result.then((groupid : IGroupid) => {
              if (!groupid) return;
              this.groupidService.add(groupid.specialty.id_specialty, groupid).subscribe({
                next: (response) => {
                  this.groupids.push(response);
                },
                error: (error) => {
                  alert(error);
                }
              });
            }).catch((error) => {});
      }

  openGroupid(id_groupid: number): void {
    this.router.navigate(['groupid', id_groupid]);
  }

  deleteGroupid(id_specialty: number, id_groupid: number, index: number): void {
    this.groupidService.delete(id_specialty, id_groupid).subscribe({
      next: (response) => {
      if (response) return;
      this.groupids.splice(index, 1);
    },
    error: (error) => alert(error)
  });
}
}
