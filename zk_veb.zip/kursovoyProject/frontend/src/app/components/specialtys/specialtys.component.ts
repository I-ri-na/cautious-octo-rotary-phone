import { Component, OnInit } from '@angular/core';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddSpecialtyComponent } from 'src/app/components/update-specialty/add-specialty.component';
import { ISpecialty } from 'src/app/models/specialty';
import { SpecialtyService } from 'src/app/service/specialty.service';

@Component({
  selector: 'app-specialtys',
  templateUrl: './specialtys.component.html',
  styleUrls: ['./specialtys.component.css']
})
export class SpecialtysComponent implements OnInit {

  specialtys: ISpecialty[];

  constructor(
    private specialtyService : SpecialtyService,
    private modalService: NgbModal,
    ) {}

  ngOnInit(): void {
    this.specialtyService.getAll().subscribe(
      {
        next: specialtys => {this.specialtys = specialtys},
        error: (error) => {}
      }
    )
  }

  openUpdateForm(id_specialty: number, index: number): void {
    let specialty = Object.assign({}, this.specialtys[index]);
    const specialtyModalBox = this.modalService.open(AddSpecialtyComponent, {centered: true});
    specialtyModalBox.componentInstance.title = "Изменить специальность";
    specialtyModalBox.componentInstance.id_specialty = id_specialty;
    specialtyModalBox.componentInstance.code_specialty = specialty.code_specialty;
    specialtyModalBox.componentInstance.name_specialty = specialty.name_specialty;
    specialtyModalBox.componentInstance.fio_headofspecialty = specialty.fio_headofspecialty;
    specialtyModalBox.componentInstance.number_headofspecialty = specialty.number_headofspecialty;
    specialtyModalBox.result.then((specialty : ISpecialty) => {
      if (!specialty) return;
      this.specialtyService.update(id_specialty, specialty).subscribe({
        next:(reponse) => {
          this.specialtys[index] = reponse;
        },
        error:(error) => alert('Ошибка при изменении, недостаточно прав доступа')
      });
    }).catch((error) => {});
  }

  openSpecialtyForm(): void {
    const specialtyModalBox = this.modalService.open(AddSpecialtyComponent, {centered: true});
    specialtyModalBox.componentInstance.title = "Добавить специальность";
    specialtyModalBox.result.then((specialty : ISpecialty) => {
          if (!specialty) return;
          this.specialtyService.add(specialty).subscribe({
            next: (response) => {
              this.specialtys.push(response);
            },
            error: (error) => {
              alert('Ошибка при добавлении, недостаточно прав доступа');
            }
          });
        }).catch((error) => {});
  }

  deleteSpecialty(id_specialty: number, index: number): void {
    this.specialtyService.delete(id_specialty).subscribe({
      next: (response) => {
      if (response) return;
      this.specialtys.splice(index, 1);
    },
    error: (error) => alert(error)
  });
}
}
