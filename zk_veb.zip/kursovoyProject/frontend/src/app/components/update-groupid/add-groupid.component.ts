import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IGroupid } from '../../models/groupid';
import { ISpecialty } from '../../models/specialty';
import { GroupidService } from '../../service/groupid.service';
import { SpecialtyService } from '../../service/specialty.service';
import { SpecialtysListComponent } from '../specialtys-list/specialtys-list.component';


@Component({
  selector: 'app-add-groupid',
  templateUrl: './add-groupid.component.html',
  styleUrls: ['./add-groupid.component.css'],
})
export class AddGroupidComponent {
  constructor(
    private activeModal: NgbActiveModal,
    private specialtyService: SpecialtyService,
    private modalService: NgbModal,
    private groupidService : GroupidService){}

  title: string;
  id_groupid: number
  number_group : number;
  specialty : ISpecialty;

  save(): void {
      if (!this.number_group) {
        alert('Не заполнены все поля')
        return;
      }
    let groupid : IGroupid = {
      id_groupid: this.id_groupid,
      number_group: this.number_group,
      specialty: this.specialty
    }

    this.activeModal.close(groupid);
    }

    openSpecialtys(): void {
        this.specialtyService.getAll().subscribe({
          next: (response) => {
            const specialtysModalBox = this.modalService.open(SpecialtysListComponent, {centered: true});
            specialtysModalBox.componentInstance.specialtys = response;
            specialtysModalBox.result.then((specialty) => {
              this.specialty = specialty;
            }).catch((error) => {});
          }
        });
      }

  close() {
    this.activeModal.close();
  }
}
