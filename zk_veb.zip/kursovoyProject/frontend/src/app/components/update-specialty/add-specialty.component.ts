import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ISpecialty } from '../../models/specialty';
import { SpecialtyService } from '../../service/specialty.service';

@Component({
  selector: 'app-add-specialty',
  templateUrl: './add-specialty.component.html',
  styleUrls: ['./add-specialty.component.css'],
})
export class AddSpecialtyComponent {
  constructor(
    private activeModal : NgbActiveModal,
    private specialtyService : SpecialtyService){}

  title: string;
  id_specialty: number
  code_specialty : string;
  name_specialty : string;
  fio_headofspecialty : string;
  number_headofspecialty : string;

  save(): void {
      if (!this.code_specialty || !this.name_specialty || !this.fio_headofspecialty || !this.number_headofspecialty) {
        alert('Не заполнены все поля')
        return;
      }
    let specialty : ISpecialty = {
      id_specialty: this.id_specialty,
      code_specialty: this.code_specialty,
      name_specialty: this.name_specialty,
      fio_headofspecialty: this.fio_headofspecialty,
      number_headofspecialty: this.number_headofspecialty
    }

    this.activeModal.close(specialty);
    }

  close() {
    this.activeModal.close();
  }
}
