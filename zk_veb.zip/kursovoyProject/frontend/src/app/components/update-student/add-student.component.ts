import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IGroupid } from '../../models/groupid';
import { IStudent } from '../../models/student';
import { GroupidService } from '../../service/groupid.service';
import { StudentService } from '../../service/student.service';
import { GroupidsListComponent } from '../groupids-list/groupids-list.component';


@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css'],
})
export class AddStudentComponent {
  constructor(
    private activeModal: NgbActiveModal,
    private studentService: StudentService,
    private modalService: NgbModal,
    private groupidService : GroupidService){}

  title: string;
  id_student: number;
  number_student: number;
  fio: string;
  date_birthday: Date;
  date_admission: number;
  number: number;
  groupid : IGroupid;

  save(): void {
      if (!this.number_student || !this.fio || !this.date_birthday || !this.date_admission || !this.number) {
        alert('Не заполнены все поля')
        return;
      }
    let student : IStudent = {
      id_student: this.id_student,
      number_student: this.number_student,
      fio: this.fio,
      date_birthday: this.date_birthday,
      date_admission: this.date_admission,
      number: this.number,
      groupid: this.groupid
    }

    this.activeModal.close(student);
    }

    openGroupids(): void {
                this.groupidService.getAll(0).subscribe({
                  next: (response) => {
                    const groupidsModalBox = this.modalService.open(GroupidsListComponent, {centered: true});
                    groupidsModalBox.componentInstance.groupids = response;
                    groupidsModalBox.result.then((groupid) => {
                      this.groupid = groupid;
                    }).catch((error) => {});
                  }
                });
              }

  close() {
    this.activeModal.close();
  }
}
