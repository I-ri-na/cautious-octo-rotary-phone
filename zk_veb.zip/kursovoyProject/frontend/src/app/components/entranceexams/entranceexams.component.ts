import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddEntranceExamComponent } from 'src/app/components/update-entranceexam/add-entranceexam.component';
import { IEntranceExam } from 'src/app/models/entranceexam';
import { EntranceExamService } from 'src/app/service/entranceexam.service';

@Component({
  selector: 'app-entranceexams',
  templateUrl: './entranceexams.component.html',
  styleUrls: ['./entranceexams.component.css']
})
export class EntranceExamsComponent implements OnInit {

  entranceexams: IEntranceExam[];

  constructor(
    private entranceexamService : EntranceExamService,
    private modalService: NgbModal,
    ) {}

  ngOnInit(): void {
    this.entranceexamService.getAll(0).subscribe(
      {
        next: entranceexams => {this.entranceexams = entranceexams},
        error: (error) => {}
      }
    )
  }

  openUpdateForm(id_entranceexam: number, index: number): void {
    let entranceexam = Object.assign({}, this.entranceexams[index]);
    const entranceexamModalBox = this.modalService.open(AddEntranceExamComponent, {centered: true});
    entranceexamModalBox.componentInstance.title = "Изменить Вступительный экзамен";
    entranceexamModalBox.componentInstance.id_entranceexam = entranceexam.id_entranceexam;
    entranceexamModalBox.componentInstance.name_exam = entranceexam.name_exam;
    entranceexamModalBox.componentInstance.result_exam = entranceexam.result_exam;
    entranceexamModalBox.componentInstance.student = entranceexam.student;
    entranceexamModalBox.result.then((entranceexam : IEntranceExam) => {
      if (!entranceexam) return;
      this.entranceexamService.update(entranceexam.student.id_student, id_entranceexam, entranceexam).subscribe({
        next:(reponse) => {
          this.entranceexams[index] = reponse;
        },
        error:(error) => alert(error)
      });
    }).catch((error) => {});
  }

  openEntranceExamForm(): void {
    const entranceexamModalBox = this.modalService.open(AddEntranceExamComponent, {centered: true});
    entranceexamModalBox.componentInstance.title = "Добавить Вступительный экзамен";
    entranceexamModalBox.result.then((entranceexam : IEntranceExam) => {
          if (!entranceexam) return;
          this.entranceexamService.add(entranceexam.student.id_student, entranceexam).subscribe({
            next: (response) => {
              this.entranceexams.push(response);
            },
            error: (error) => {
              alert(error);
            }
          });
        }).catch((error) => {});
  }


  deleteEntranceExam(id_student: number,id_entranceexam: number, index: number): void {
    this.entranceexamService.delete(id_student, id_entranceexam).subscribe({
      next: (response) => {
      if (response) return;
      this.entranceexams.splice(index, 1);
    },
    error: (error) => alert(error)
  });
}
}
