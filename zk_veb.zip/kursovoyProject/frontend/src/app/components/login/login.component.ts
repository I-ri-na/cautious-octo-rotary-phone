import { Component} from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpErrorResponse } from '@angular/common/http';
import { ISpecialty } from 'src/app/models/specialty';
import { SpecialtyService } from 'src/app/service/specialty.service';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{
constructor(
        private specialtyService: SpecialtyService,
        private router: Router,
        private modalService: NgbModal,
        private authService: AuthService,
    ) {}

  specialtys: ISpecialty[]
  errormark: boolean
  login: string
  password: string
  sub: any

  onClick()
  {
  console.log(this.login);
  this.errormark=false;
  sessionStorage.setItem('login',this.login);
  sessionStorage.setItem('password',this.password);

  if(this.authService.checkRole('user','user') || this.authService.checkRole('admin','admin'))
  {
  this.sub=this.specialtyService.getAll().subscribe(specialtys=>{this.specialtys=specialtys;
  console.log(specialtys);

  this.router.navigate(["specialtys"])},(e:HttpErrorResponse)=>{console.log("err"+e.status+e.message);this.errormark=true;});
  }
  else {
      alert('Аккаунт не найден. Повторите попытку ввода')
  }
  }

}
