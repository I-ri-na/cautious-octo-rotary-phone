import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IGroupid } from 'src/app/models/groupid';
import { IStudent } from 'src/app/models/student';
import { GroupidService } from 'src/app/service/groupid.service';
import { StudentService } from 'src/app/service/student.service';
import { AddStudentComponent } from '../update-student/add-student.component';

@Component({
  selector: 'app-groupid',
  templateUrl: './groupid.component.html',
  styleUrls: ['./groupid.component.css']
})
export class GroupidComponent implements OnInit {

  groupid: IGroupid;
  students: IStudent[];

  constructor(
    private groupidService: GroupidService,
    private studentsService: StudentService,
    private route: ActivatedRoute,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    this.groupidService.get(0,id).subscribe({
      next: (groupid) => {this.groupid = groupid},
      error: (error) => {}
    });
    this.studentsService.getAll(id).subscribe(
      {
        next: students => {this.students = students},
        error: (error) => {}
      }
    );
  }

  openAddStudentForm(): void {

    const studentModalBox = this.modalService.open(AddStudentComponent, {centered: true});
    studentModalBox.componentInstance.title = "Добавление студента";
    studentModalBox.componentInstance.groupid = Object.assign({}, this.groupid);
    studentModalBox.componentInstance.groupidEnable = false;
    studentModalBox.result.then((student : IStudent) => {
      if (!student) return;
      this.studentsService.add(this.groupid.id_groupid, student).subscribe({
        next: (response) => {
          this.students.push(response);
        },
        error: (error) => {
          alert(error);
        }
      });
    }).catch((error) => {});
  }

  openUpdateStudentForm(id_student: number, index: number): void {
    let student = Object.assign({}, this.students[index]);
    const studentModalBox = this.modalService.open(AddStudentComponent, {centered: true});
    studentModalBox.componentInstance.title = "Изменить cтудента";
    studentModalBox.componentInstance.id_student = student.id_student;
    studentModalBox.componentInstance.number_student = student.number_student;
    studentModalBox.componentInstance.fio = student.fio;
    studentModalBox.componentInstance.date_birthday = student.date_birthday;
    studentModalBox.componentInstance.date_admission = student.date_admission;
    studentModalBox.componentInstance.number = student.number;
    studentModalBox.componentInstance.groupid = student.groupid;
    studentModalBox.componentInstance.groupidEnable = false;
    studentModalBox.result.then((student : IStudent) => {
      if (!student) return;
      this.studentsService.update(student.groupid.id_groupid, id_student, student).subscribe({
        next:(reponse) => {
          this.students[index] = reponse;
        },
        error:(error) => alert(error)
      });
    }).catch((error) => {});
  }

  deleteStudent(id_groupid: number, id: number, index: number): void {
    this.studentsService.delete(id_groupid, id).subscribe({
      next: (response) => {
        if (!response) return;
        this.students.splice(index, 1);
      },
      error: (error) => alert(error)
  });
  }
}
