import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { IStudent } from 'src/app/models/student';

@Component({
  selector: 'app-students-list',
  templateUrl: './students-list.component.html',
  styleUrls: ['./students-list.component.css']
})
export class StudentsListComponent {
  students: IStudent[];

  constructor(
    private activeModal: NgbActiveModal
  ) {}


  save(student: IStudent) {
    this.activeModal.close(student);
  }

  close() {
    this.activeModal.close();
  }
}
