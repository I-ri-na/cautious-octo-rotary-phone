import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IGroupid } from '../../models/groupid';
import { ILearningPlan } from '../../models/learningplan';
import { GroupidService } from '../../service/groupid.service';
import { LearningPlanService } from '../../service/learningplan.service';
import { GroupidsListComponent } from '../groupids-list/groupids-list.component';

@Component({
  selector: 'app-add-learningplan',
  templateUrl: './add-learningplan.component.html',
  styleUrls: ['./add-learningplan.component.css'],
})
export class AddLearningPlanComponent {
  constructor(
    private activeModal: NgbActiveModal,
    private learningplanService: LearningPlanService,
    private modalService: NgbModal,
    private groupidService : GroupidService){}

  title: string;
  id_learningplan: number
  code_discipline : number;
  number_semester : number;
  count_hours : number;
  groupid : IGroupid;

  save(): void {
      if (!this.code_discipline || !this.number_semester || !this.count_hours) {
        alert('Не заполнены все поля')
        return;
      }
    let learningplan : ILearningPlan = {
      id_learningplan: this.id_learningplan,
      code_discipline: this.code_discipline,
      number_semester: this.number_semester,
      count_hours: this.count_hours,
      groupid: this.groupid
    }

    this.activeModal.close(learningplan);
    }

    openGroupids(): void {
            this.groupidService.getAll(0).subscribe({
              next: (response) => {
                const groupidsModalBox = this.modalService.open(GroupidsListComponent, {centered: true});
                groupidsModalBox.componentInstance.groupids = response;
                groupidsModalBox.result.then((groupid) => {
                  this.groupid = groupid;
                }).catch((error) => {});
              }
            });
          }

  close() {
    this.activeModal.close();
  }
}
