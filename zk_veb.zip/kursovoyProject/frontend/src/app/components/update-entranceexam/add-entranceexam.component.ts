import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IStudent } from '../../models/student';
import { IEntranceExam } from '../../models/entranceexam';
import { StudentService } from '../../service/student.service';
import { EntranceExamService } from '../../service/entranceexam.service';
import { StudentsListComponent } from '../students-list/students-list.component';

@Component({
  selector: 'app-add-entranceexam',
  templateUrl: './add-entranceexam.component.html',
  styleUrls: ['./add-entranceexam.component.css'],
})
export class AddEntranceExamComponent {
  constructor(
    private activeModal: NgbActiveModal,
    private entranceexamService: EntranceExamService,
    private modalService: NgbModal,
    private studentService : StudentService){}

  title: string;
  id_entranceexam: number;
  name_exam : string;
  result_exam : number;
  student: IStudent;

  save(): void {
      if (!this.name_exam || !this.result_exam) {
        alert('Не заполнены все поля')
        return;
      }
    let entranceexam : IEntranceExam = {
      id_entranceexam: this.id_entranceexam,
      name_exam: this.name_exam,
      result_exam: this.result_exam,
      student: this.student
    }

    this.activeModal.close(entranceexam);
    }

  openStudents(): void {
        this.studentService.getAll(0).subscribe({
          next: (response) => {
            const studentsModalBox = this.modalService.open(StudentsListComponent, {centered: true});
            studentsModalBox.componentInstance.students = response;
            studentsModalBox.result.then((student) => {
              this.student = student;
            }).catch((error) => {});
          }
        });
      }

  close() {
    this.activeModal.close();
  }
}
