import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { IGroupid } from 'src/app/models/groupid';

@Component({
  selector: 'app-groupids-list',
  templateUrl: './groupids-list.component.html',
  styleUrls: ['./groupids-list.component.css']
})
export class GroupidsListComponent {
  groupids: IGroupid[];

  constructor(
    private activeModal: NgbActiveModal
  ) {}


  save(groupid: IGroupid) {
    this.activeModal.close(groupid);
  }

  close() {
    this.activeModal.close();
  }
}
