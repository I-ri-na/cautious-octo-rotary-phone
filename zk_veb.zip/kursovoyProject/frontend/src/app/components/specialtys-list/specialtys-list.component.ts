import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ISpecialty } from 'src/app/models/specialty';

@Component({
  selector: 'app-specialtys-list',
  templateUrl: './specialtys-list.component.html',
  styleUrls: ['./specialtys-list.component.css']
})
export class SpecialtysListComponent {
  specialtys: ISpecialty[];

  constructor(
    private activeModal: NgbActiveModal
  ) {}


  save(specialty: ISpecialty) {
    this.activeModal.close(specialty);
  }

  close() {
    this.activeModal.close();
  }
}
