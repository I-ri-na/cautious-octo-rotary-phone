import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddStudentComponent } from 'src/app/components/update-student/add-student.component';
import { IStudent } from 'src/app/models/student';
import { StudentService } from 'src/app/service/student.service';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {

  students: IStudent[];

  constructor(
    private studentService : StudentService,
    private modalService: NgbModal,
    ) {}

  ngOnInit(): void {
    this.studentService.getAll(0).subscribe(
      {
        next: students => {this.students = students},
        error: (error) => {}
      }
    )
  }

  openUpdateForm(id_student: number, index: number): void {
    let student = Object.assign({}, this.students[index]);
    const studentModalBox = this.modalService.open(AddStudentComponent, {centered: true});
    studentModalBox.componentInstance.title = "Изменить студента";
    studentModalBox.componentInstance.id_student = student.id_student;
    studentModalBox.componentInstance.number_student = student.number_student;
    studentModalBox.componentInstance.fio = student.fio;
    studentModalBox.componentInstance.date_birthday = student.date_birthday;
    studentModalBox.componentInstance.date_admission = student.date_admission;
    studentModalBox.componentInstance.number = student.number;
    studentModalBox.componentInstance.groupid = student.groupid;
    studentModalBox.result.then((student : IStudent) => {
      if (!student) return;
      this.studentService.update(student.groupid.id_groupid, id_student, student).subscribe({
        next:(reponse) => {
          this.students[index] = reponse;
        },
        error:(error) => alert('Ошибка при изменении, недостаточно прав доступа')
      });
    }).catch((error) => {});
  }

  openStudentForm(): void {
    const studentModalBox = this.modalService.open(AddStudentComponent, {centered: true});
    studentModalBox.componentInstance.title = "Добавить студента";
    studentModalBox.result.then((student : IStudent) => {
          if (!student) return;
          this.studentService.add(student.groupid.id_groupid, student).subscribe({
            next: (response) => {
              this.students.push(response);
            },
            error: (error) => {
              alert('Ошибка при добавлении, не достаточно прав доступа');
            }
          });
        }).catch((error) => {});
  }

  openStudent(id_student: number): void {

  }

  deleteStudent(id_groupid: number,id_student: number, index: number): void {
    this.studentService.delete(id_groupid, id_student).subscribe({
      next: (response) => {
      if (response) return;
      this.students.splice(index, 1);
    },
    error: (error) => alert(error)
  });
}
}
