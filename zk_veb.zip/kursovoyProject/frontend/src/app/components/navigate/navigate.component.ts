import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ISpecialty } from 'src/app/models/specialty';
import { SpecialtyService } from 'src/app/service/specialty.service';

@Component({
  selector: 'app-navigate',
  templateUrl: './navigate.component.html',
  styleUrls: ['./navigate.component.css']
})
export class NavigateComponent {
  constructor(
    private specialtyService : SpecialtyService,
    private modalService: NgbModal,
    ) {}

    specialtys: ISpecialty[];

  ngOnInit(): void {
    this.specialtyService.getAll().subscribe(
      {
        next: specialtys => {this.specialtys = specialtys},
        error: (error) => {}
      }
    )
  }

}
