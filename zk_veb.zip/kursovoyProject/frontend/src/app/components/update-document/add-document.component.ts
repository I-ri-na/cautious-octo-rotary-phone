import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IStudent } from '../../models/student';
import { IDocument } from '../../models/document';
import { StudentService } from '../../service/student.service';
import { DocumentService } from '../../service/document.service';
import { StudentsListComponent } from '../students-list/students-list.component';


@Component({
  selector: 'app-add-document',
  templateUrl: './add-document.component.html',
  styleUrls: ['./add-document.component.css'],
})
export class AddDocumentComponent {
  constructor(
    private activeModal: NgbActiveModal,
    private documentService: DocumentService,
    private modalService: NgbModal,
    private studentService : StudentService){}

  title: string;
  id_document: number;
  name_document : string;
  have_document : boolean;
  student: IStudent;

  save(): void {
      if (!this.name_document || !this.have_document) {
        alert('Не заполнены все поля')
        return;
      }
    let document : IDocument = {
      id_document: this.id_document,
      name_document: this.name_document,
      have_document: this.have_document,
      student: this.student
    }

    this.activeModal.close(document);
    }

      openStudents(): void {
            this.studentService.getAll(0).subscribe({
              next: (response) => {
                const studentsModalBox = this.modalService.open(StudentsListComponent, {centered: true});
                studentsModalBox.componentInstance.students = response;
                studentsModalBox.result.then((student) => {
                  this.student = student;
                }).catch((error) => {});
              }
            });
          }

  close() {
    this.activeModal.close();
  }
}
