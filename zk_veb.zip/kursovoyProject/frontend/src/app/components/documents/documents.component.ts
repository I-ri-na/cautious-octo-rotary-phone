import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddDocumentComponent } from 'src/app/components/update-document/add-document.component';
import { IDocument } from 'src/app/models/document';
import { DocumentService } from 'src/app/service/document.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.css']
})
export class DocumentsComponent implements OnInit {

  documents: IDocument[];

  constructor(
    private documentService : DocumentService,
    private modalService: NgbModal,
    ) {}

  ngOnInit(): void {
    this.documentService.getAll(0).subscribe(
      {
        next: documents => {this.documents = documents},
        error: (error) => {}
      }
    )
  }

  openUpdateForm(id_document: number, index: number): void {
    let document = Object.assign({}, this.documents[index]);
    const documentModalBox = this.modalService.open(AddDocumentComponent, {centered: true});
    documentModalBox.componentInstance.title = "Изменить Документ";
    documentModalBox.componentInstance.id_document = document.id_document;
    documentModalBox.componentInstance.name_document = document.name_document;
    documentModalBox.componentInstance.have_document = document.have_document;
    documentModalBox.componentInstance.student = document.student;
    documentModalBox.result.then((document : IDocument) => {
      if (!document) return;
      this.documentService.update(document.student.id_student, id_document, document).subscribe({
        next:(reponse) => {
          this.documents[index] = reponse;
        },
        error:(error) => alert(error)
      });
    }).catch((error) => {});
  }

  openDocumentForm(): void {
    const documentModalBox = this.modalService.open(AddDocumentComponent, {centered: true});
    documentModalBox.componentInstance.title = "Добавить документ";
    documentModalBox.result.then((document : IDocument) => {
          if (!document) return;
          this.documentService.add(document.student.id_student, document).subscribe({
            next: (response) => {
              this.documents.push(response);
            },
            error: (error) => {
              alert(error);
            }
          });
        }).catch((error) => {});
  }

  deleteDocument(id_student: number,id_document: number, index: number): void {
    this.documentService.delete(id_student, id_document).subscribe({
      next: (response) => {
      if (response) return;
      this.documents.splice(index, 1);
    },
    error: (error) => alert(error)
  });
}
}
