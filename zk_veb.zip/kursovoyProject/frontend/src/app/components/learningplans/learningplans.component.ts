import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddLearningPlanComponent } from 'src/app/components/update-leearningplan/add-learningplan.component';
import { ILearningPlan } from 'src/app/models/learningplan';
import { LearningPlanService } from 'src/app/service/learningplan.service';

@Component({
  selector: 'app-learningplans',
  templateUrl: './learningplans.component.html',
  styleUrls: ['./learningplans.component.css']
})
export class LearningPlansComponent implements OnInit {

  learningplans: ILearningPlan[];

  constructor(
    private learningplanService : LearningPlanService,
    private modalService: NgbModal,
    ) {}

  ngOnInit(): void {
    this.learningplanService.getAll(0).subscribe(
      {
        next: learningplans => {this.learningplans = learningplans},
        error: (error) => {}
      }
    )
  }

  openUpdateForm(id_learningplan: number, index: number): void {
    let learningplan = Object.assign({}, this.learningplans[index]);
    const learningplanModalBox = this.modalService.open(AddLearningPlanComponent, {centered: true});
    learningplanModalBox.componentInstance.title = "Изменить Учебный план";
    learningplanModalBox.componentInstance.id_learningplan = learningplan.id_learningplan;
    learningplanModalBox.componentInstance.code_discipline = learningplan.code_discipline;
    learningplanModalBox.componentInstance.number_semester = learningplan.number_semester;
    learningplanModalBox.componentInstance.count_hours = learningplan.count_hours;
    learningplanModalBox.componentInstance.groupid = learningplan.groupid;
    learningplanModalBox.result.then((learningplan : ILearningPlan) => {
      if (!learningplan) return;
      this.learningplanService.update(learningplan.groupid.id_groupid, id_learningplan, learningplan).subscribe({
        next:(reponse) => {
          this.learningplans[index] = reponse;
        },
        error:(error) => alert('Ошибка при изменении, недостаточно прав доступа')
      });
    }).catch((error) => {});
  }

  openLearningPlanForm(): void {
    const learningplanModalBox = this.modalService.open(AddLearningPlanComponent, {centered: true});
    learningplanModalBox.componentInstance.title = "Добавить учебный план";
    learningplanModalBox.result.then((learningplan : ILearningPlan) => {
          if (!learningplan) return;
          this.learningplanService.add(learningplan.groupid.id_groupid, learningplan).subscribe({
            next: (response) => {
              this.learningplans.push(response);
            },
            error: (error) => {
              alert('Ошибка при добавлении, недостаточно прав доступа');
            }
          });
        }).catch((error) => {});
  }

  deleteLearningPlan(id_groupid: number,id_learningplan: number, index: number): void {
    this.learningplanService.delete(id_groupid, id_learningplan).subscribe({
      next: (response) => {
      if (response) return;
      this.learningplans.splice(index, 1);
    },
    error: (error) => alert(error)
  });
}
}
