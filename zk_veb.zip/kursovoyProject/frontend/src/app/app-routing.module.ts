import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SpecialtysComponent } from './components/specialtys/specialtys.component';
import { GroupidsComponent } from './components/groupids/groupids.component';
import { GroupidComponent } from './components/groupid/groupid.component';
import { LearningPlansComponent } from './components/learningplans/learningplans.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { EntranceExamsComponent } from './components/entranceexams/entranceexams.component';
import { StudentsComponent } from './components/students/students.component';
import { LoginComponent } from './components/login/login.component';
import { UserguardGuard } from 'src/app/guards/userguard.guard';
import { AdminguardGuard } from 'src/app/guards/adminguard.guard';

const routes: Routes = [
  {path: '', component:  LoginComponent},
  //{path: '..?continue', component:  LoginComponent},
  {path: 'specialtys', component:  SpecialtysComponent, canActivate: [UserguardGuard]},
  {path: 'students', component:  StudentsComponent, canActivate: [UserguardGuard]},
  {path: 'groupids', component:  GroupidsComponent, canActivate: [UserguardGuard]},
  {path: 'groupid/:id', component:  GroupidComponent, canActivate: [AdminguardGuard]},
  {path: 'learningplans', component:  LearningPlansComponent, canActivate: [UserguardGuard]},
  {path: 'documents', component:  DocumentsComponent, canActivate: [UserguardGuard]},
  {path: 'entranceexams', component:  EntranceExamsComponent, canActivate: [UserguardGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
