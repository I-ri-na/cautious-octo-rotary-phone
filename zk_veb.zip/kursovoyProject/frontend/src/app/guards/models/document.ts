import { IStudent } from "./student";

export interface IDocument {
    id_document: number,
    name_document: string,
    have_document: boolean,
    student: IStudent
}
