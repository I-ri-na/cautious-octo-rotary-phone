import { IGroupid } from "./groupid";

export interface ILearningPlan {
    id_learningplan: number,
    code_discipline: number,
    number_semester: number,
    count_hours: number,
    groupid: IGroupid
}
