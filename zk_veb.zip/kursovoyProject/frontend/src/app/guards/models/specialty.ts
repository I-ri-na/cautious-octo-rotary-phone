export interface ISpecialty {
    id_specialty: number,
    code_specialty: string,
    name_specialty: string,
    fio_headofspecialty: string,
    number_headofspecialty: string
}
