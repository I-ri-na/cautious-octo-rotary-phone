import { IGroupid } from "./groupid";

export interface IStudent {
    id_student: number,
    number_student: number,
    fio: string,
    date_birthday: Date,
    date_admission: number,
    number: number,
    groupid: IGroupid
}
