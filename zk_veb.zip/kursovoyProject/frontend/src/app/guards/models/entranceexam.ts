import { IStudent } from "./student";

export interface IEntranceExam {
    id_entranceexam: number,
    name_exam: string,
    result_exam: number,
    student: IStudent
}
