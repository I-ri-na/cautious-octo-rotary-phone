import { ISpecialty } from "./specialty";

export interface IGroupid {
    id_groupid: number,
    number_group: number,
    specialty: ISpecialty
}
