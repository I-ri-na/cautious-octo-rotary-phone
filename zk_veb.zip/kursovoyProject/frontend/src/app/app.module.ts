import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { SpecialtysComponent } from './components/specialtys/specialtys.component';
import { StudentsComponent } from './components/students/students.component';
import { LearningPlansComponent } from './components/learningplans/learningplans.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { EntranceExamsComponent } from './components/entranceexams/entranceexams.component';
import { GroupidsComponent } from './components/groupids/groupids.component';
import { GroupidComponent } from './components/groupid/groupid.component';
import { LoginComponent } from './components/login/login.component';
import { NavigateComponent } from './components/navigate/navigate.component';
import { AddSpecialtyComponent } from './components/update-specialty/add-specialty.component';
import { AddStudentComponent } from './components/update-student/add-student.component';
import { AddGroupidComponent } from './components/update-groupid/add-groupid.component';
import { AddLearningPlanComponent } from './components/update-leearningplan/add-learningplan.component';
import { AddDocumentComponent } from './components/update-document/add-document.component';
import { AddEntranceExamComponent } from './components/update-entranceexam/add-entranceexam.component';
import { SpecialtysListComponent } from './components/specialtys-list/specialtys-list.component';
import { GroupidsListComponent } from './components/groupids-list/groupids-list.component';
import { StudentsListComponent } from './components/students-list/students-list.component';



@NgModule({
  declarations: [
    AppComponent,
    NavigateComponent,
    SpecialtysComponent,
    StudentsComponent,
    GroupidsComponent,
    GroupidComponent,
    DocumentsComponent,
    LearningPlansComponent,
    EntranceExamsComponent,
    AddSpecialtyComponent,
    AddStudentComponent,
    AddGroupidComponent,
    AddLearningPlanComponent,
    AddDocumentComponent,
    AddEntranceExamComponent,
    SpecialtysListComponent,
    GroupidsListComponent,
    StudentsListComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
