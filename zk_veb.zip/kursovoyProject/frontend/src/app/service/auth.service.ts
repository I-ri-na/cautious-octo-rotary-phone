import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable,BehaviorSubject,catchError,map,of,tap,throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private _httpClient: HttpClient) {}

  login(login: string, password: string): Observable<boolean> {
    if(!this.isLoggedIn()) {
      sessionStorage.setItem('login', login);
      sessionStorage.setItem('password', password);
    }
    return this._httpClient.get<void>(environment.apiUrl + 'login').pipe(
      map(() => true),
      catchError(error => {
      this.logout()
      return of(false);
      })
    );
  }

  logout(){
  if(this.isLoggedIn()) {
       sessionStorage.removeItem('login');
       sessionStorage.removeItem('password');
    }
  }

  isLoggedIn(): boolean {
    return sessionStorage.hasOwnProperty('login') &&
           sessionStorage.hasOwnProperty('password')
    }

    getLoginParams(): { login: string, password: string } {
      const login = sessionStorage.getItem('login') || '';
      const password = sessionStorage.getItem('password') || '';
      return { login, password };
    }

    checkRole(login: string, password: string): boolean {
      return sessionStorage.getItem('login')==login &&
        sessionStorage.getItem('password')==password;
    }
}
