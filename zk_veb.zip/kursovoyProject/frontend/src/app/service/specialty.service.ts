import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ISpecialty } from 'src/app/models/specialty';

@Injectable({
  providedIn: 'root'
})
export class SpecialtyService {

  constructor(private http: HttpClient) { }

  getAll(): Observable<ISpecialty[]> {
    return this.http.get<ISpecialty[]>(`${environment.apiUrl}/api/specialty?search`);
  }

  get(id_specialty: number): Observable<ISpecialty> {
    return this.http.get<ISpecialty>(`${environment.apiUrl}/api/specialty/${id_specialty}`);
  }

  add(specialty: ISpecialty): Observable<ISpecialty> {
    return this.http.post<ISpecialty>(`${environment.apiUrl}/api/specialty`, specialty);
  }

  update(id_specialty: number, specialty: ISpecialty): Observable<ISpecialty> {
    return this.http.put<ISpecialty>(`${environment.apiUrl}/api/specialty/${id_specialty}`, specialty);
  }

  delete(id_specialty: number): Observable<boolean> {
    return this.http.delete<boolean>(`${environment.apiUrl}/api/specialty/${id_specialty}`);
  }
}
