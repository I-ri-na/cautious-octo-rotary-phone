import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IDocument } from 'src/app/models/document';

@Injectable({
  providedIn: 'root'
})
export class DocumentService {

  constructor(private http: HttpClient) { }

  getAll(id_student: number): Observable<IDocument[]> {
    return this.http.get<IDocument[]>(`${environment.apiUrl}/api/student/${id_student}/document`);
  }

  get(id_student: number,id_document: number): Observable<IDocument> {
    return this.http.get<IDocument>(`${environment.apiUrl}/api/student/${id_student}/document/${id_document}`);
  }

  add(id_student: number,document: IDocument): Observable<IDocument> {
    return this.http.post<IDocument>(`${environment.apiUrl}/api/student/${id_student}/document`, document);
  }

  update(id_student: number, id_document: number, document: IDocument): Observable<IDocument> {
    return this.http.put<IDocument>(`${environment.apiUrl}/api/student/${id_student}/document/${id_document}`, document);
  }

  delete(id_student: number,id_document: number): Observable<boolean> {
    return this.http.delete<boolean>(`${environment.apiUrl}/api/groupid/${id_student}/document/${id_document}`);
  }
}
