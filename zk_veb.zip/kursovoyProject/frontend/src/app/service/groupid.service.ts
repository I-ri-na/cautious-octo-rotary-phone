import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IGroupid } from 'src/app/models/groupid';

@Injectable({
  providedIn: 'root'
})
export class GroupidService {

  constructor(private http: HttpClient) { }

  getAll(id_specialty: number): Observable<IGroupid[]> {
    return this.http.get<IGroupid[]>(`${environment.apiUrl}/api/specialty/${id_specialty}/groupid`);
  }

  get(id_specialty: number, id_groupid: number): Observable<IGroupid> {
    return this.http.get<IGroupid>(`${environment.apiUrl}/api/specialty/${id_specialty}/groupid/${id_groupid}`);
  }

  add(id_specialty: number, groupid: IGroupid): Observable<IGroupid> {
    return this.http.post<IGroupid>(`${environment.apiUrl}/api/specialty/${id_specialty}/groupid`, groupid);
  }

  update(id_specialty: number, id_groupid: number, groupid: IGroupid): Observable<IGroupid> {
    return this.http.put<IGroupid>(`${environment.apiUrl}/api/specialty/${id_specialty}/groupid/${id_groupid}`, groupid);
  }

  delete(id_specialty: number, id_groupid: number): Observable<boolean> {
    return this.http.delete<boolean>(`${environment.apiUrl}/api/specialty/${id_specialty}/groupid/${id_groupid}`);
  }
}
