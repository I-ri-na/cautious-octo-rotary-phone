import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IStudent } from 'src/app/models/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http: HttpClient) { }

  getAll(id_groupid: number): Observable<IStudent[]> {
    return this.http.get<IStudent[]>(`${environment.apiUrl}/api/groupid/${id_groupid}/student`);
  }

  get(id_groupid: number,id_student: number): Observable<IStudent> {
    return this.http.get<IStudent>(`${environment.apiUrl}/api/groupid/${id_groupid}/student/${id_student}`);
  }

  add(id_groupid: number,student: IStudent): Observable<IStudent> {
    return this.http.post<IStudent>(`${environment.apiUrl}/api/groupid/${id_groupid}/student`, student);
  }

  update(id_groupid: number, id_student: number, student: IStudent): Observable<IStudent> {
    return this.http.put<IStudent>(`${environment.apiUrl}/api/groupid/${id_groupid}/student/${id_student}`, student);
  }

  delete(id_groupid: number,id_student: number): Observable<boolean> {
    return this.http.delete<boolean>(`${environment.apiUrl}/api/groupid/${id_groupid}/student/${id_student}`);
  }
}
