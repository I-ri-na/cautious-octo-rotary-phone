import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ILearningPlan } from 'src/app/models/learningplan';

@Injectable({
  providedIn: 'root'
})
export class LearningPlanService {

  constructor(private http: HttpClient) { }

  getAll(id_groupid: number): Observable<ILearningPlan[]> {
    return this.http.get<ILearningPlan[]>(`${environment.apiUrl}/api/groupid/${id_groupid}/learningplan`);
  }

  get(id_groupid: number,id_learningplan: number): Observable<ILearningPlan> {
    return this.http.get<ILearningPlan>(`${environment.apiUrl}/api/groupid/${id_groupid}/learningplan/${id_learningplan}`);
  }

  add(id_groupid: number,learningplan: ILearningPlan): Observable<ILearningPlan> {
    return this.http.post<ILearningPlan>(`${environment.apiUrl}/api/groupid/${id_groupid}/learningplan`, learningplan);
  }

  update(id_groupid: number, id_learningplan: number, learningplan: ILearningPlan): Observable<ILearningPlan> {
    return this.http.put<ILearningPlan>(`${environment.apiUrl}/api/groupid/${id_groupid}/learningplan/${id_learningplan}`, learningplan);
  }

  delete(id_groupid: number,id_learningplan: number): Observable<boolean> {
    return this.http.delete<boolean>(`${environment.apiUrl}/api/groupid/${id_groupid}/learningplan/${id_learningplan}`);
  }
}
