import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IEntranceExam } from 'src/app/models/entranceexam';

@Injectable({
  providedIn: 'root'
})
export class EntranceExamService {

  constructor(private http: HttpClient) { }

  getAll(id_student: number): Observable<IEntranceExam[]> {
      return this.http.get<IEntranceExam[]>(`${environment.apiUrl}/api/student/${id_student}/entranceexam`);
    }

  get(id_student: number,id_entranceexam: number): Observable<IEntranceExam> {
    return this.http.get<IEntranceExam>(`${environment.apiUrl}/api/student/${id_student}/entranceexam/${id_entranceexam}`);
  }

  add(id_student: number,entranceexam: IEntranceExam): Observable<IEntranceExam> {
    return this.http.post<IEntranceExam>(`${environment.apiUrl}/api/student/${id_student}/entranceexam`, entranceexam);
  }

  update(id_student: number, id_entranceexam: number, entranceexam: IEntranceExam): Observable<IEntranceExam> {
    return this.http.put<IEntranceExam>(`${environment.apiUrl}/api/student/${id_student}/entranceexam/${id_entranceexam}`, entranceexam);
  }

  delete(id_student: number,id_entranceexam: number): Observable<boolean> {
    return this.http.delete<boolean>(`${environment.apiUrl}/api/student/${id_student}/entranceexam/${id_entranceexam}`);
  }
}
