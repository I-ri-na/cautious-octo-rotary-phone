import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthinterceptorService {
  constructor(private auth_service: AuthService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<eny>> {
    let loginParams = this.auth_service.getLoginParams()

    if(loginParams.username && loginParams.password) {
      const basicAuthHeader = 'Basic ' + btoa(loginParams.username + ':' + loginParams.password);
      request = request.clone({
        setHeaders: {
          Authorization: basicAuthHeader
        }
      });
    }
    return next.handle(request);
  }
}
